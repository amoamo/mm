#### 2016-09-01 @amo 修改
- 增加 product-detail.html
- css目录中增加product-detail.css


#### 09-18 BCI
##### 前台
- 增加templates目录：模板
- 增加api目录：mock数据
- 更新了main.css
- 增加product-detail.js
- 更新product-detail.html
- 更新product-detail.css
- 加了js/mustache.min.js
#### 2016-09-01 @amo 修改
- 增加 product-detail.html
- css目录中增加product-detail.css


#### BCI
##### 前台
###### 09-18
- 增加templates目录：模板
- 增加api目录：mock数据
- 更新了main.css
- 增加product-detail.js
- 更新product-detail.html
- 更新product-detail.css
- 加了js/mustache.min.js

###### 09-19
- 增加js/portfolio.js
- 更新api目录
- 更新templates目录

- 增加js/qa.js
- 增加qa.html
- 更新api目录
- 更新templates目录
- 更新css/main.css
